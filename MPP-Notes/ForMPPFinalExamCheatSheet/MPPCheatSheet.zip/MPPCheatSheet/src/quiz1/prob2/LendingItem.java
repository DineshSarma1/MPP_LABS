package MPPPretest.prob2;

import java.util.Comparator;
import java.util.Objects;

public class LendingItem {
	private int numCopiesInLib;

	public int getNumCopiesInLib() {
		return numCopiesInLib;
	}

	public void setNumCopiesInLib(int numCopiesInLib) {
		this.numCopiesInLib = numCopiesInLib;
	}

	
	
}
