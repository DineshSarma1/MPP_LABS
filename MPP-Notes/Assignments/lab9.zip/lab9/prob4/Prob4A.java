package lesson9.labs.prob4;

public class Prob4A {

}
